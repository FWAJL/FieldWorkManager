jQuery.ready(function() {

     $("#btn_login_submit").click();


});