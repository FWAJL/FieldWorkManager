    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="Web/js/jquery.js"></script>
    <script src="Web/js/bootstrap.min.js"></script>  

</body></html>