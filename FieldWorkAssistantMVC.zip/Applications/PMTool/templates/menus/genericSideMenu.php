<div class="collapse navbar-collapse navbar-ex1-collapse">
  <ul class="nav navbar-nav side-nav">
<?php
//Menu side
$menuSide = new MenuSideSimple($appSessionManager);
$menuSide->Init();
?>
  </ul>
</div>