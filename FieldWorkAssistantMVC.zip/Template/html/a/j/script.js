$(document).ready(function(){
    $('.slide-trigger').collapsable();
});