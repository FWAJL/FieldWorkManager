<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UrlKeys
 *
 * @author jl
 */

namespace Library\Enums\ResourceKeys;

class PublicPageUrls {
  /**
   * Relative Urls
   */
  /**
   * Absolute Urls
   */
    const HomeUrl = "HomeUrl";
    const AboutUrl = "AboutUrl";
    const ResumeUrl = "ResumeUrl";
    const ContactUrl = "ContactUrl";
}

?>
