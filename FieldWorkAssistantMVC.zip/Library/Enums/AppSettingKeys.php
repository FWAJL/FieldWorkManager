<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AppSettings
 *
 * @author jl
 */
namespace Library\Enums;

abstract class AppSettingKeys {
  const Config_test = "test";
  
  const DefaultLanguage = "DefaultLanguage";
}

?>
